
--HELO WELCOME BASE FATHER TEAM
-- AUTHOR : TINO GUSTINO, TSABITALFH
--- INFO SCRIPT : DONT DELETE AUTHOR SCRIPT
-- HARGAI PEMBUAT
-- JASA ENC/DEC 081535365496
--%%%%%%%%%%%%%%%%%%%%%%%

if gg.BUILD < 5511 then -- CHECK VERSION GG
gg.alert('You need more new version of GG for run this script. At least build 5511.')

function Exit() -- FUNGSI KELUAR ALL MENU
  print("📌Thanks For Use My Script")
  gg.alert("【Good Byee, See You Next Time】")
  gg.alert("【SCRIPT END】")
  print("💾 Base By Tino Gustino")
  print("🤖 Recode  By Tino Gustino")
  gg.setVisible(true)
  os.exit()
end--Fᴜɴᴄᴛɪᴏɴ

function t0xFoBYsf() -- FUNGSI ALERT HOME
  gg.setVisible(false)
  lobyAlert = gg.alert(os.date("🔔WELCOME IN MY SCRIPT\n📅Today : %d/%m/%Y\n🔍Time   : %H:%M "), "[MENU]", "[EXIT]")
  if lobyAlert == 2 then
    Exit()
  end--Iғ
end--Fᴜɴᴄᴛɪᴏɴ

--MENAMPILKAN LOBY---
HOME = 1
t0xFoBYsf()

--FUNCTION MAIN MENU------
function Main()
  mainMenu = gg.choice({
    "🚫🚫⇲\t MENU 1    ",
    "🚫🚫⇲  MENU 2   ",
    "🚫🚫⇲  MENU 3        ",
    "🚫🚫⇲  MENU 4 ",
    "🚫🚫⇲  MENU 5  ",
    "〖 EXIT〗"
  }, nil, (os.date("🔔WELCOME IN MY SCRIPT\n📅Today : %d/%m/%Y\n🔍Time Loggin : %H:%M ")))
  if mainMenu == 1 then
    menu1() -- JIKA MAIN MENU 1 DITEKAN KEMUDIAN JALANKAN  FUNGSI menu1
  end
  if mainMenu == 2 then
    menu2()-- JIKA MAIN MENU 2 DITEKAN KEMUDIAN JALANKAN  FUNGSI menu2
    end
  if mainMenu == 3 then
    menu3()-- JIKA MAIN MENU 3 DITEKAN KEMUDIAN JALANKAN  FUNGSI menu3
  end
  if mainMenu == 4 then
    menu4()-- JIKA MAIN MENU 4 DITEKAN KEMUDIAN JALANKAN  FUNGSI menu4
  end
  if mainMenu == 5 then
    menu5()-- JIKA MAIN MENU 5 DITEKAN KEMUDIAN JALANKAN  FUNGSI menu5
  end
  if mainMenu == 6 then
    Exit() -- jalankan fungsi Exit
  end
  GLWW = -1 -- Menu Show
end 


------------FUNCTION MENU RESULT ------
function menu1() --FUNGSION MENU 1
  playerMenu = gg.choice({
    "🚫🚫⇲\t GodMod",
    "🚫🚫⇲\t CSPD",
    "🚫🚫⇲  ASPD",
    "〖 Back〗"
  }, nil, (os.date("💀💀~~ihaveSoMuchHaters~~💀💀\nToday : %d/%m/%Y \nTime   : %H:%M ")))
  if playerMenu == 1 then
  goodmode()
  end--function
  
  if playerMenu == 2 then
  goodmode2()
  end--function
  
  if playerMenu == 3 then
  goodmode3()
  end--function
  
  if playerMenu == 4 then
    Main()
  end--Iғ
  GLWW = -1
end--Fᴜɴᴄᴛɪᴏɴ


function menu2()
---Langsung Code.Guardian
-- Untuk Buat Menu silahkan Copas Menu1 ganti parameter

end
function menu3()
---Langsung Code.Guardian
-- Untuk Buat Menu silahkan Copas Menu1 ganti parameter
end
function menu4()
---Langsung Code.Guardian
-- Untuk Buat Menu silahkan Copas Menu1 ganti parameter
end
function menu5()
---Langsung Code.Guardian
-- Untuk Buat Menu silahkan Copas Menu1 ganti parameter
end

-----------END


------------+++++FUNGSION CPP /RESULT GG++++++-----
function goodmode()
--nilai game guardian
gg.toast("Script Inject")
end
function goodmode2()
--nilai game guardian
gg.toast("Script Inject")
end
function goodmode3()
--nilai game guardian
gg.toast("Script Inject")
end




--JANGAN DIHAPOS/EDIT  NTAR ERROR KONTOL
while true do
  if gg.isVisible(true) then
    GLWW = 1
    gg.setVisible(false)
  end--Iғ
  gg.clearResults()
  if GLWW == 1 then
    Main()
  end--Iғ
end--Wʜɪʟᴇ

print("Tino Author") --Jangan dihapos... Lu copy Paster brooo... kasian yang buat
print("🇲🇨THANK YOU VIP MEMBER FOR USING MY SCRIPT🇲🇨")
gg.setVisible(true)
os.exit()
